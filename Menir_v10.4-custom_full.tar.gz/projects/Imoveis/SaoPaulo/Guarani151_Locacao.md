﻿# Guarani 151 LocaÃ§Ã£o

## Contexto
HistÃ³rico de locaÃ§Ã£o do imÃ³vel Guarani 151 em SÃ£o Paulo.

## Status
ARQUIVADO

## Linha do Tempo
- [2018] Contrato de locaÃ§Ã£o
- [2025-09-14] Indexado no Training U
