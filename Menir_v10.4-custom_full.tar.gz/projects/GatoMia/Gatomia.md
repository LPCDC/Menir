# Função Gatomia

## Contexto  
Gatomia é a função central do Menir que agrega todos os projetos existentes em uma visão consolidada.

## Projetos
- [Itaú](../Itau/Itau.md)  
- [Renderizador](../Renderizador/Renderizador.md)  
- [Imóveis](../Imoveis/Imoveis.md)  
- [Textos](../Textos/Textos.md)  

## Status  
CENTRAL  
