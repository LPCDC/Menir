# Casos de Uso - LibLabs AI Playbook

## Caso 1 - Automação de Documentação Revit
- **Antes**: 4h de trabalho manual para criar sheets e tags.
- **Depois (ArchiLabs/IA)**: 15min, sem erros de template.

## Caso 2 - Pesquisa de Produtos Sustentáveis
- **Antes**: 2 dias de pesquisa manual em catálogos.
- **Depois (IA/NLP)**: lista gerada em minutos, com metadados de conformidade.

## Caso 3 - Orçamentação e Quantitativos
- **Antes**: estimativa manual sujeita a erros.
- **Depois (IA assistida)**: quantificação automática, checada em QA.

---
**Métrica alvo**: economia de 70% do tempo em tarefas repetitivas até 2026.
