#!/usr/bin/env python
"""
MCP / JSON-RPC 2.0 server mínimo para Menir-10.

Métodos expostos:

- ping
    → {"status": "Menir alive"}

- boot_now
    → Lê arquivos canônicos do repositório e devolve um JSON de estado, por ex.:
      {
        "timestamp": "...",
        "repo_root": "/workspaces/Menir",
        "last_boot_now": "<conteúdo ou null>",
        "menir_plan_excerpt": "<primeiros N caracteres ou null>",
        "notes": [...]
      }

Entrada/saída:
- STDIN: uma linha JSON por requisição.
- STDOUT: uma linha JSON-RPC 2.0 por resposta.

Também loga cada chamada em mcp_operations.jsonl na raiz do repo.
"""

from __future__ import annotations

import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional

SCRIPT_PATH = Path(__file__).resolve()
REPO_ROOT = SCRIPT_PATH.parent.parent
LOG_PATH = REPO_ROOT / "mcp_operations.jsonl"
MAX_TEXT_BYTES = 64000


def log_event(event: Dict[str, Any]) -> None:
    """Acrescenta um evento JSONL em mcp_operations.jsonl (best-effort)."""
    try:
        LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
        with LOG_PATH.open("a", encoding="utf-8") as f:
            json.dump(event, f, ensure_ascii=False)
            f.write("\n")
    except Exception:
        # Não quebra o servidor se logging falhar
        pass


def safe_read_text(path: Path, max_bytes: int = MAX_TEXT_BYTES) -> Optional[str]:
    """Lê até max_bytes de um arquivo de texto; devolve None se não existir/der erro."""
    if not path.exists():
        return None
    try:
        data = path.read_bytes()[:max_bytes]
        return data.decode("utf-8", errors="replace")
    except Exception:
        return None


def handle_ping(params: Dict[str, Any] | None) -> Dict[str, Any]:
    return {"status": "Menir alive"}


def handle_boot_now(params: Dict[str, Any] | None) -> Dict[str, Any]:
    """
    Carrega estado canônico mínimo do Menir a partir do repositório.

    Arquivos considerados:
    - last_boot_now.json (raiz)
    - MENIR_PLAN.md (raiz)
    """
    now = datetime.now().astimezone().isoformat()

    # last_boot_now.json
    last_boot_path = REPO_ROOT / "last_boot_now.json"
    last_boot_raw = safe_read_text(last_boot_path)

    # MENIR_PLAN.md (apenas um trecho para não lotar o JSON)
    menir_plan_path = REPO_ROOT / "MENIR_PLAN.md"
    menir_plan_raw = safe_read_text(menir_plan_path)
    menir_plan_excerpt = menir_plan_raw[:8000] if menir_plan_raw else None

    notes = []

    if last_boot_raw:
        notes.append("last_boot_now.json encontrado na raiz do repositório.")
    else:
        notes.append("last_boot_now.json NÃO encontrado na raiz do repositório.")

    if menir_plan_raw:
        notes.append("MENIR_PLAN.md encontrado; excerpt incluído em menir_plan_excerpt.")
    else:
        notes.append("MENIR_PLAN.md NÃO encontrado na raiz do repositório.")

    # Pasta menir10/
    menir10_dir = REPO_ROOT / "menir10"
    if menir10_dir.is_dir():
        notes.append("Pasta menir10/ presente.")
    else:
        notes.append("Pasta menir10/ NÃO encontrada; verificar estrutura do repo.")

    return {
        "timestamp": now,
        "repo_root": str(REPO_ROOT),
        "last_boot_now": last_boot_raw,
        "menir_plan_excerpt": menir_plan_excerpt,
        "notes": notes,
    }


METHODS = {
    "ping": handle_ping,
    "boot_now": handle_boot_now,
}


def main() -> None:
    # Mensagem inicial no stderr só para debug humano
    print("MCP server ready (Menir-10)", file=sys.stderr, flush=True)

    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue

        try:
            req = json.loads(line)
        except json.JSONDecodeError:
            # Ignora linhas inválidas
            continue

        jsonrpc = req.get("jsonrpc")
        method = req.get("method")
        req_id = req.get("id")
        params = req.get("params")

        # Log de entrada (best-effort)
        log_event(
            {
                "ts": datetime.utcnow().isoformat() + "Z",
                "direction": "in",
                "request": req,
            }
        )

        if jsonrpc != "2.0" or method not in METHODS:
            response = {
                "jsonrpc": "2.0",
                "error": {
                    "code": -32601,
                    "message": f"Unknown method '{method}'",
                },
                "id": req_id,
            }
        else:
            try:
                handler = METHODS[method]
                result = handler(params if isinstance(params, dict) else None)
                response = {
                    "jsonrpc": "2.0",
                    "result": result,
                    "id": req_id,
                }
            except Exception as exc:
                response = {
                    "jsonrpc": "2.0",
                    "error": {
                        "code": -32000,
                        "message": f"Internal error in method '{method}': {exc}",
                    },
                    "id": req_id,
                }

        # Log de saída
        log_event(
            {
                "ts": datetime.utcnow().isoformat() + "Z",
                "direction": "out",
                "response": response,
            }
        )

        sys.stdout.write(json.dumps(response, ensure_ascii=False) + "\n")
        sys.stdout.flush()


if __name__ == "__main__":
    main()
