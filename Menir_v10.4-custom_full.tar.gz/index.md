﻿# Training U â€” Menu Geral

## NÃºcleo
- [Training U â€” GPT-5 Controls](projects/TrainingU/Training_U_gpt5_controls.md)

## Projetos
- [ItaÃº](projects/Itau/Itau.md)
  - [Proposta 15220012](projects/Itau/Propostas/Proposta_15220012.md)
  - [JurÃ­dico](projects/Itau/Processos/Juridico.md)
  - [Extratos](projects/Itau/Processos/Extratos_Indexados.md)

- [Renderizador](projects/Renderizador/Renderizador.md)
  - [TÃ¢nia](projects/Renderizador/Tania/Tania.md)
    - [FamÃ­lia Otani](projects/Renderizador/Tania/Familia_Otani/Familia_Otani.md)

- [ImÃ³veis](projects/Imoveis/Imoveis.md)
  - [Santos](projects/Imoveis/Santos/Santos.md)
  - [SÃ£o Paulo](projects/Imoveis/SaoPaulo/SaoPaulo.md)
    - [Guarani 151 LocaÃ§Ã£o](projects/Imoveis/SaoPaulo/Guarani151_Locacao.md)

- [Textos](projects/Textos/Textos.md)
  - [Subprojeto 1](projects/Textos/Subprojeto1/Subprojeto1.md)
  - [Subprojeto 2](projects/Textos/Subprojeto2/Subprojeto2.md)

---

ðŸ“Œ **Regras:**
- SEMPRE criar um .md por projeto/subprojeto.
- ATUALIZAR este index.md quando abrir algo novo.
- STATUS deve aparecer no cabeÃ§alho de cada .md.
