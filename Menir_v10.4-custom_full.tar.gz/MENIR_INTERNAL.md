# MENIR_INTERNAL – Menir-10

Comandos principais (raiz do repositório):

- BootNow (Codespace): `python scripts/boot_now.py`
- Tests: `pytest -q && python -m unittest discover -v`
- Export (exemplo): `python menir10_export.py --help`
- Daily report (exemplo): `python scripts/menir10_daily_report.py`

Ambientes:
- Codespace: `/workspaces/Menir`
- PC: `C:\Users\Pichau\Repos\Menir`

Git:
- Atualizar: `git pull origin main`
- Commit: `git add . && git commit -m "Atualiza MENIR_INTERNAL"`
- Push: `git push origin main`

# MENIR_INTERNAL – Menir-10

Comandos principais (raiz do repositório):

- BootNow (Codespace): `python scripts/boot_now.py`
- Tests: `pytest -q && python -m unittest discover -v`
- Export (exemplo): `python menir10_export.py --help`
- Daily report (exemplo): `python scripts/menir10_daily_report.py`

Ambientes:
- Codespace: `/workspaces/Menir`
- PC: `C:\Users\Pichau\Repos\Menir`

Git:
- Atualizar: `git pull origin main`
- Commit: `git add . && git commit -m "Atualiza MENIR_INTERNAL"`
- Push: `git push origin main`


# MENIR_INTERNAL – Manual mínimo do Menir-10

## 1. Estado atual (Menir-10 v5.x)

- Repositório canônico: `LPCDC/Menir` (branch `main`).
- O que está ATIVO hoje:
  - `scripts/boot_now.py`
    - Registra eventos de boot em `logs/operations.jsonl`.
    - Já está coberto por testes (pytest/unittest OK).
  - Módulos `menir10_export`, `menir10_insights`, `menir10_daily_report`
    - Testes passando, prontos para trabalhar com **logs de interações** em JSONL
      (ex.: `menir10_interactions.jsonl`), quando esse logger existir.
- O que AINDA NÃO está implementado:
  - Memory Server / FastAPI / Neo4j (RISK-001, RISK-002, etc.).
  - Logger automático de interações GPT → `menir10_interactions.jsonl`.
  - Qualquer consulta obrigatória ao grafo antes da resposta do GPT.

Resumo: hoje o Menir-10 já funciona como **camada de boot + logging auditável**.
O grafo Neo4j e o “oráculo de riscos” entram no Capítulo 2.

---

## 2. Uso diário mínimo (PC ou Codespaces)

### 2.1. Boot por projeto

Dentro da pasta do repositório:

```bash
cd /workspaces/Menir
export MENIR_PROJECT_ID=tivoli   # (no Windows: set MENIR_PROJECT_ID=tivoli)
python scripts/boot_now.py
```

## Fluxo rápido 1 — Boot com MENIR_PROJECT_ID obrigatório (CLI)

Comando padrão de boot do Menir-10 (não usar mais `python scripts/boot_now.py` direto):

```bash
export MENIR_PROJECT_ID=tivoli        # ou itau_15220012, ibere, etc.
python scripts/menir10_boot_cli.py
```

## Fluxo rápido 2 — Registrar evento/interação por projeto (CLI)

Registrar um evento rápido associado a um `project_id` (usa `MENIR_PROJECT_ID` se omitido):

```bash
# usa MENIR_PROJECT_ID se definido
python scripts/menir10_log_cli.py -c "Reunião breve sobre cronograma"

# ou forneça explicitamente o projeto
python scripts/menir10_log_cli.py -p itau_15220012 -c "Ligação com gerente"
```

---

## 3. Como usar depois disso

No **PC** ou no Codespace, depois de um `git pull`:

### 3.1. Boot por projeto (sempre com `MENIR_PROJECT_ID`)

```bash
cd /c/Users/Pichau/Repos/Menir      # no PC
# ou
cd /workspaces/Menir                # no Codespace

export MENIR_PROJECT_ID=tivoli      # (Windows: set MENIR_PROJECT_ID=tivoli)
python scripts/menir10_boot_cli.py
```

### 3.2. Registrar evento rápido durante trabalho

```bash
# com MENIR_PROJECT_ID já definido
python scripts/menir10_log_cli.py -c "Conversou com síndico sobre imóvel"

# ou especificar projeto inline
python scripts/menir10_log_cli.py -p itau_15220012 -c "Checkpoint: gerente confirmou prazo"
```

### 3.3. Testes

```bash
# Executar todos os testes (pytest + unittest)
pytest -q && python -m unittest discover -v

# Ou separado:
pytest -q                              # testes pytest (repo-root)
python -m unittest discover -v         # testes unittest (package)
```

### 3.4. Exportar e consultar logs

```bash
# Exportar interações do projeto para Cypher
python menir10_export.py

# Ver projetos mais ativos
python scripts/menir10_insights.py top --top-n 5

# Ver contexto de um projeto específico
python scripts/menir10_insights.py context tivoli --limit 20

# Gerar relatório diário (salva em arquivo ou stdout)
python scripts/menir10_daily_report.py --out daily_context.md
```

---

## 4. Estrutura de arquivos (resumo)

- `menir10/` — Pacote canônico Menir-10 (PerceptionState, logging, insights, export).
- `scripts/menir10_boot_cli.py` — CLI de boot com `MENIR_PROJECT_ID` obrigatório.
- `scripts/menir10_log_cli.py` — CLI para registrar eventos rápidos por projeto.
- `scripts/boot_now.py` — Script original de boot (chamado por `menir10_boot_cli.py`).
- `logs/menir10_interactions.jsonl` — Log JSONL de eventos por projeto (criado automaticamente).
- `logs/operations.jsonl` — Log de operações de boot (criado por `boot_now.py`).
- `.github/workflows/menir10-tests.yml` — CI do GitHub Actions que roda testes em push/PR.

---

## 5. Notas de manutenção

- **Wrapper**: `menir10_export.py` (repo-root) é um wrapper fino que delega para `menir10.menir10_export` (pacote).
  - Isso permite que testes antigos continuem funcionando.
  - A implementação canônica fica em `menir10/menir10_export.py`.
- **Testes**: CI roda `pytest -q` + `python -m unittest discover -v` em toda alteração.
- **Git**: Regras do servidor obrigam PR para `main`, mas atualmente há bypass (consulte o time).
- **Ambientes**: O Codespace e o PC devem estar sincronizados com `git pull origin main` antes de usar.
