# checkpoint.md
timestamp: 2025-10-23T17:04:28.969969-03:00
project: banco_itau
items:
  - type: draft_email
    title: Protocolo e CET — Proposta 15220012
    sha256: c2668d7f57e9cd8db45bdf0aa4c6312b98bfda624bab9cd76b293bea528ca6f7
  - type: timeline
    title: Contrato 15220012 — Linha do Tempo
    sha256: 0b7fefb693618baaf65604d73e803f1dcf8c4db3cca7679c2b72fe6611ffda72
notes:
  - sources: gmail (registro-eletronico.itau@credimobiliario.com.br, TransBPO)
  - legal: Lei 9.514/1997; Res. CMN 4.881/2020; Res. CMN 3.517/2007
