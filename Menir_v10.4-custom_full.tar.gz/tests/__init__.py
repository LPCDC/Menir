"""Tests for menir10 package."""
