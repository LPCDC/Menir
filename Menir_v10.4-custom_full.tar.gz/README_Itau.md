# Pacote Itaú — Menir Judicial Dataset

Este pacote organiza dados bancários do caso Itaú no Menir (Neo4j Aura).

## Estrutura

