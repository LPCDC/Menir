# Pipeline README (MENIR)
- Bronze: brutos (EML/XML/PDF)
- Silver: normalizados (JSONL/CSV)
- Gold: Neo4j (índices e vínculos)
- Dedupe + quarentena + LGPD minimization
